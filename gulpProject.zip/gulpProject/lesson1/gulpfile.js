var gulp = require('gulp');
var concat = require('gulp-concat');
gulp.task('script', function(){
		return gulp.src("lib/*.js").pipe(concat("build.js")).pipe(gulp.dest("dist/"));
		 gulp.watch('lib/*.js',['script']);


});
/*gulp.task('w1',function(){
	gulp.watch('lib/*.js',['script']);
});*/

gulp.task('default',['script']);

/*gulp.task('default',['script']);*//*npm i -D gulp-concat*//*npm install gulp -D*/